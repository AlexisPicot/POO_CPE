public class Armure extends Item {
    // Votre code ici
}
