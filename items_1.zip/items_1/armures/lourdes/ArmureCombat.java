
public class ArmureCombat extends Armure {
    // Votre code ici
}
