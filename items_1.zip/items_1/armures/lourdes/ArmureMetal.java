
public class ArmureMetal extends Armure {
    // Votre code ici
}
