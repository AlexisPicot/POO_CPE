
public class ArmureAssault extends Armure {
    // Votre code ici
}
