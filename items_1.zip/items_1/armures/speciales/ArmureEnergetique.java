
public class ArmureEnergetique extends Armure {
    // Votre code ici
}
