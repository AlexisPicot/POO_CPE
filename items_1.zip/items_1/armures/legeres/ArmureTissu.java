
public class ArmureTissu extends Armure {
    // Votre code ici
}
