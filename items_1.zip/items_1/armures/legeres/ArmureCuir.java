
public class ArmureCuir extends Armure {
    // Votre code ici
}
