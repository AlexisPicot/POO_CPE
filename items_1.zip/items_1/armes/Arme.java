public class Arme extends Item {
    // Votre code ici
}
