public class FusilPrecision extends Arme {
    // Votre code ici
}
