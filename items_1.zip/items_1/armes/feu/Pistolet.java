public class Pistolet extends Arme {
    // Votre code ici
}
