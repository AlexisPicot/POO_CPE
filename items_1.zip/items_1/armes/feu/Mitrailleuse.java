public class Mitrailleuse extends Arme {
    // Votre code ici
}
