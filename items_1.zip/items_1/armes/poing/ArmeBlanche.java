public class ArmeBlanche extends Arme {
    // Votre code ici
}
