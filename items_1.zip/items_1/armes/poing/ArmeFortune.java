public class ArmeFortune extends Arme {
    // Votre code ici
}
