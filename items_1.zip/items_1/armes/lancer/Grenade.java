public class Grenade extends Arme {
    // Votre code ici
}
