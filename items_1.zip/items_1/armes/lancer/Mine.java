public class Mine extends Arme {
    // Votre code ici
}
